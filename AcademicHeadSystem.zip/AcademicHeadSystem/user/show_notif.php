
<style>
#alert_popover{
	position:fixed; 
    bottom: 0px; 
    left: 0px; 
    width: 100%;
    z-index:9999; 
    border-radius:0px
}

#inner-message {
    margin: 0 auto;
}</style>

<?php 
session_start();
include('connection.php');
include('tags.php');

$username = $_SESSION['username'];


$announce_query = mysqli_query($conn, "SELECT * FROM tbl_announcement  ORDER BY id DESC;");



$total_notif = mysqli_num_rows($announce_query); 

echo '<b><li class="dropdown-header">TOTAL NOTIFICATIONS: '.$total_notif.' </li></b>';
echo '<li class="divider"></li>';

echo '<li class="dropdown-header">Announcement for Today</li>';

if(mysqli_num_rows($announce_query) > 0){
    while($row = mysqli_fetch_array($announce_query)){ 
// $announce_date = $_POST['announce_date'];
        echo '
        <div style="font-size: 13px; background: #f9f9f9; padding: 5px; margin: 5px; width: 300px; ">
        <a href="announcements_notif.php">
        <b>'.$row['title'].'</b> 
        <br>
        ';

       // echo time_elapsed_string(strtotime($row['announce_time']));
        echo $row['announce_date']. ' - ' .$row['announce_time']; 
?>

        </a>
            <br/>
        </div>


        <?php echo '
        ';
        }
}
else{
    echo 'No records yet.';

}

echo '<li class="divider"></li>';

// else {
//     echo '<li class="text-center" style="padding: 5px;">No new Notification</li>';
                 
// }



date_default_timezone_set('Asia/Manila'); // set the timezone to Asia/Manila

function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $ago->setTimezone(new DateTimeZone('Asia/Manila')); // set the timezone to Asia/Manila
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}







?>
