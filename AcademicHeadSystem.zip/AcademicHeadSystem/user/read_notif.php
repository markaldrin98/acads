<?php 
session_start();
include('connection.php');
include('tags.php');
//$username = $_SESSION['username'];
//$query = mysqli_query($conn, "SELECT * FROM tbl_test");
// $announce_query = mysqli_query($conn, "UPDATE tbl_test SET status_notif='Read' WHERE status='Pending'");

echo mysqli_num_rows($announce_query);

?>