<?php 
session_start();
include('tags.php');

include('connection.php');
?>


<head>
<title>Academic Head System</title>
</head>
<body>
<?php include('header.php'); ?>
        <!-- page content area main -->
        <div class="container fontStyle" style="margin-top: 100px;">       
            <br>
                <div class="row justify-content-center">
                    <center>     
                        <h2>Manage Student</h2>
                        <br>
                        <?php 
                        $res = mysqli_query($conn, "SELECT * FROM tbl_student order by ID desc");
                        if($res){
                          $rowcount = mysqli_num_rows($res);
                        }
                        
                        ?>    
                        
                        <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addBtn">Add New Student</button>            
                        <br><br>
                        <table class='table table-bordered table-striped'>
                          <tr style="background: #d9d9d9 !important; text-align: center;">
                            <th>ID</th>
                            <th>Last Name</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Age</th>
                            <th>Phone No</th>
                            <th>Address</th>
                            <th>Course</th>
                            <th>Section</th>
                            <th>Year Level</th>
                            <th>Subject</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Edit</th>
                            <th>Delete</th>                                                               
                          </tr>
                        <?php while($row = mysqli_fetch_array($res)){ ?>
                          <tr>
                            <td><?php echo $row["id"]; ?> </td>
                            <td><?php echo $row["last_name"]; ?></td>
                            <td><?php echo $row["first_name"]; ?></td>
                            <td><?php echo $row["middle_name"]; ?></td>           
                            <td><?php echo $row["age"]; ?></td>
                            <td><?php echo $row["phone_no"]; ?></td> 
                            <td><?php echo $row["address"]; ?> </td>
                            <td><?php echo $row["course"]; ?></td>
                            <td><?php echo $row["section"]; ?></td>
                            <td><?php echo $row["year_level"]; ?></td>           
                            <td><?php echo $row["subject"]; ?></td>
                            <td><?php echo $row["stud_date"]; ?></td>        
                            <td><?php echo $row["stud_time"]; ?></td>              
                            <td><?php echo '<button class="btn btn-warning editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td>
                            <td><?php echo '<button class="btn btn-danger deleteUser" data-toggle="modal" data-target="#deleteUser">Delete</button>' ?> </td>
                          </tr>
                          <?php
                          }
                          ?>
                        </table>
                    </center>
                  </div>
                </div>

<!-- Add Modal -->
<div id="addBtn" class="modal fade fontStyle" role="dialog">
  <div class="modal-dialog modal-lg">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add New User</h4>
      </div>     

      <div class="modal-body">
        <form action="" method="post">  
          <div class="row">
            <div class="col-lg-4">
              <div class="form-group">
                <label for="usr">Last Name:</label>
                <input type="text" name="last_name" class="form-control" required>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="form-group">
                <label for="usr">First Name:</label>
                <input type="text" name="first_name" class="form-control" required>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="form-group">
                <label for="usr">Middle Name:</label>
                <input type="text" name="middle_name" class="form-control">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-6">
              <div class="form-group">
                <label for="usr">Age:</label>
                <input type="number" name="age" class="form-control" required >
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-group">
                <label for="usr">Phone No:</label>
                <input type="number" name="phone_no" class="form-control" required>
              </div>  
            </div>  
          </div>
          <div class="form-group">
            <label for="usr">Address:</label>
            <input type="text" name="address" class="form-control" required>
          </div>


          <div class="row">
            <div class="col-lg-6">
              <div class="form-group">
                <label for="usr">Course:</label>
                <input type="text" name="course" class="form-control" required>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-group">
                <label for="usr">Section:</label>
                <input type="text" name="section" class="form-control">
              </div>
            </div>
          </div>


          <div class="row">
            <div class="col-lg-6">
              <div class="form-group">
                <label for="usr">Year Level:</label>
                <input type="text" name="year_level" class="form-control" required >
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-group">
                <label for="usr">Subject:</label>
                <input type="phone_no" name="subject" class="form-control" required>
              </div>    
            </div>
          </div>


          <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date("Y-m-d");?>" name="stud_date"/>
          <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date('h:i:s');?>" name="stud_time"/>


        </div>

        <div class="modal-footer">
          <button type="submit" name="addData" class="btn btn-primary">Add User</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Add Modal -->        

<!-- Update Modal -->
<div id="editBtn" class="modal fade fontStyle" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Update User</h4>
      </div>     

      <div class="modal-body">
        <form action="" method="post">
        <input id="update_id" name="update_id" type="hidden">

          <div class="form-group">
            <label for="usr">Last Name:</label>
            <input type="text" name="last_name" id="last_name" class="form-control" required>
          </div>

          <div class="form-group">
            <label for="usr">First Name:</label>
            <input type="text" name="first_name" id="first_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Middle Name:</label>
            <input type="text" name="middle_name" id="middle_name" class="form-control">
          </div>
          <div class="form-group">
            <label for="usr">Age:</label>
            <input type="number" name="age" id="age" class="form-control" readonly required>
          </div> 
          <div class="form-group">
            <label for="usr">Phone No:</label>
            <input type="number" name="phone_no" id="phone_no" class="form-control" required>
          </div>    
          <div class="form-group">
            <label for="usr">Address:</label>
            <input type="text" name="address" id="address" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Course:</label>
            <input type="text" name="course" id="course" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Section:</label>
            <input type="text" name="section" id="section" class="form-control">
          </div>
          <div class="form-group">
            <label for="usr">Year Level:</label>
            <input type="text" name="year_level" id="year_level" class="form-control" required >
          </div>
          <div class="form-group">
            <label for="usr">Subject:</label>
            <input type="phone_no" name="subject" id="subject" class="form-control" required>
          </div>


        </div>

        <div class="modal-footer">
          <button type="submit" name="updateData" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Update Modal -->


<!-- Delete Modal -->
<div id="deleteUser" class="modal fade fontStyle" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete User</h4>
        </div>
      <form action="" method="post">
        <div class="modal-body">
          <input id="delete_id" name="delete_id" type="hidden">
          <p>Are you sure you want to delete this User?</p>
        </div>
        <div class="modal-footer">
          <button type="submit" name="deleteData" class="btn btn-danger">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>  
  </div>
</div>
<!-- ADD QUERY [ADD NEW USER] -->  
<?php 
  if(isset($_POST["addData"]))
     {
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $age = $_POST['age'];
        $phone_no = $_POST['phone_no'];
        $address = $_POST['address'];
        $course = $_POST['course'];
        $section = $_POST['section'];
        $year_level = $_POST['year_level'];
        $subject = $_POST['subject'];
        $stud_date = $_POST['stud_date'];
        $stud_time = $_POST['stud_time'];
        $query_show = mysqli_query($conn, "SELECT * FROM tbl_student");
        
        $query = mysqli_query($conn, "SELECT * FROM tbl_student WHERE age='$age'");
         if(mysqli_num_rows($query) > 0) 
         {
             echo '<div class="alert alert-danger fontStyle" style="width: 100% !important;">
             <center> The age you entered already exists.</center>
        </div>';
         }
         else 
         {
           // ones na lumagpas sa 3 yung magreregister sa kanya, i-aalert nya yung baba.
          
              //else, i-eexecute nya yung insert query
              $query_insert = mysqli_query($conn, "INSERT INTO tbl_student 
                  VALUES('', '$last_name', '$first_name', '$middle_name', 
                  '$age', '$phone_no', '$address', '$course', '$section', 
                  '$year_level', '$subject', '$stud_date', '$stud_time')");
                if($query_insert)
                {            
                  echo '<script> window.location="credentials.php";</script>';  
                  /*
                echo ' <div class="alert alert-success fontStyle" style="width: 100% !important;">
                <center> Registration successfully </center>
                       </div>';
                       */
                
            
            }
          }
      }


 


     if(isset($_POST['updateData'])){    
         
        $id = $_POST['update_id'];
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $age = $_POST['age'];
        $phone_no = $_POST['phone_no'];
        $address = $_POST['address'];
        $course = $_POST['course'];
        $section = $_POST['section'];
        $year_level = $_POST['year_level'];
        $subject = $_POST['subject'];
        // $stud_date = $_POST['stud_date'];
        // $stud_time = $_POST['stud_time'];








        $query = mysqli_query($conn, "UPDATE tbl_student SET last_name='$last_name', first_name='$first_name', middle_name='$middle_name', age='$age', phone_no='$phone_no', address='$address', course='$course', section='$section', year_level='$year_level', subject='$subject', stud_date='$stud_date' WHERE id='$id'");
        if($query) {
            echo '<script> window.location="credentials.php";</script>';  
     /*
            echo '<div class="alert alert-success" style="width: 100% !important;">
            <center>
            Successfully Updated
            </center>
            </div>';
     */
        }
        
     }

     if(isset($_POST['deleteData'])){    
        $id = $_POST['delete_id'];
        $query = mysqli_query($conn, "DELETE FROM tbl_student WHERE id='$id'");
        if($query) {
          echo '<script> window.location="credentials.php";</script>';  
          /*
            echo '<div class="alert alert-success fontStyle" style="width: 100% !important;">
            <center>
               Successfully Deleted
            </center>
            </div>';
            */
        }
     }
?>  

<!-- End of Delete Modal -->
</body>


<script>
    $(document).ready(function(){
        $('.editBtn').on('click', function(){           
           // $('#editBtn').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();

            $('#update_id').val(data[0]);
            $('#last_name').val(data[1]);
            $('#first_name').val(data[2]);
            $('#middle_name').val(data[3]);
            $('#age').val(data[4]);
            $('#phone_no').val(data[5]); 
            $('#address').val(data[6]);
            $('#course').val(data[7]);
            $('#section').val(data[8]);
            $('#year_level').val(data[9]);
            $('#subject').val(data[10]);       
        });
    });

</script>

<script>
    $(document).ready(function(){
        $('.deleteUser').on('click', function(){
            
         //   $('#deleteUser').modal('show');

       //     $('#deleteUser').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_id').val(data[0]);          
        });
    });
</script>
</body>
</html>
