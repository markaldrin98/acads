

<?php 
session_start();
include('connection.php');
include('tags.php');
//$username = $_SESSION['username'];

//$query = mysqli_query($conn, "SELECT * FROM tbl_announcement_notif");



$announce_query = mysqli_query($conn, "SELECT * FROM tbl_announcement");


echo mysqli_num_rows($announce_query);

$announce_count_query = mysqli_query($conn, "SELECT COUNT(1) FROM tbl_announcement");
$announce_row = mysqli_fetch_array($announce_count_query);




$announce_total = $announce_row[0];


// counts notification
if(mysqli_num_rows($announce_query) == 1){
    echo '<div id="alert_popover">
    <div id="inner-message" class="alert alert-info" >
        You have '. $announce_total .' new notification!
    </div>
    </div>';
}
elseif(mysqli_num_rows($announce_query) > 0){
    echo '<div id="alert_popover">
    <div id="inner-message" class="alert alert-info">
        You have '. $announce_total .' new notifications!
    </div>
    </div>';
}




?>