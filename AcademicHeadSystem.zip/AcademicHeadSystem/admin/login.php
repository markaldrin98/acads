<?php 
include('connection.php');
include('tags.php');

session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Academic Head System</title>
    <style>
@font-face {
  font-family: 'Poppins', sans-serif;
  src: url('fonts/Poppins-Regular.otf');
}
 *{
  font-family: 'Poppins', sans-serif;
}


 body {
    background: white;
     overflow-x: hidden !important;
     overflow-y: hidden !important;
 }
 .fontStyle{
  font-family: 'Poppins', sans-serif;

}

img {
  vertical-align: middle;
  border-style: none;
}

 .box {
    display: table;
    width: 100%;
    height: 100vh;
    background: white;

    
}
.box-cell {
    display: table-cell;
    vertical-align: middle;
    
}


.btn-home {
  background-color: #0085fe !important;
  border-color: #0085fe !important;
}

.btn-home:hover {
  background-color: #005eb3 !important;
  border-color: #005eb3 !important;
}


.grad {
     background-image: linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1));
}

.login-box-cell {
    width: 450px;
    margin: auto;
    
    padding: 15px; 
}
.login-panel {
   box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2); 
    padding: 30px;
    border-radius: 6px;
}
.alertClass {
   width: 100% !important;
   padding: -15px !important;
}

@media (min-width:320px)  { /* smartphones, portrait iPhone, portrait 480x320 phones (Android) */ }
@media (min-width:480px)  { /* smartphones, Android phones, landscape iPhone */ }
@media (min-width:600px)  { /* portrait tablets, portrait iPad, e-readers (Nook/Kindle), landscape 800x480 phones (Android) */ }
@media (min-width:801px)  { /* tablet, landscape iPad, lo-res laptops ands desktops */ }
@media (max-width:1025px) {  body {overflow: scroll !important;} .d-none-pic {display:none;}     /* big landscape tablets, laptops, and desktops */ }
@media (min-width:1281px) { /* hi-res laptops and desktops */ }
</style>
</head>
<body>
<div class="row h-100 fontStyle">
    <div class="col-lg-6">
        <div class="box" >
            <div class="box-cell" >  
                <div style="margin-bottom: 80px;" class="row" style=" ">                               
                        <!-- <div style="display: inline-block; font-size: 2rem; margin-left: 100px;">PATIENTS RECORD MANAGEMENT SYSTEM</div> -->
                          <div style="display: inline-block; font-size: 2rem; margin-left: 100px;">
                            <a href="index.php"><button class="btn btn-primary">Back</button></a>
                        </div> 
                </div>
                <div class="login-box-cell">
                    <div class="login-panel" style="margin-bottom: 150px;">
                        <center>
                            <img class="img-fluid" src="../img/logoschool.png" width="100">
                        
                        <div class="row lead" style="margin-top: 25px; font-size: 18px;">
                            LOG IN AS ADMINISTRATOR
                        </div>
                        </center>
                    <br>
                    <h6 class="text-center lead" style="font-size: 1.5rem;  font-weight: bold; margin-top: -40px;"></h6>
                    
                    <h6 class="text-center lead" style="font-size: 15px;"></h6>
                        <form action="" method="post">
                        <div class="form-group-lg">
                            <h6 for="username" style="font-size: 17px;">Username:</h6>
                            <input type="text" name="username"  class="form-control form-control-lg mb-4" maxlength="11" required>
                        </div>
                        <div class="form-group-lg" style="margin-top: 25px;">
                            <h6 for="password" style="font-size: 17px;">Password:</h6>
                            <input type="password" name="password"  class="form-control form-control-lg" maxlength="11" required>
                        </div>
                          <div class="form-group-lg mb-4" style="margin-top: 25px;">
                        <span><input type="submit" class="btn btn-block btn-primary btn-home" style="border-radius: 50px; font-size: 22px; " value="Log In" name="login"></span>
                        </form>
               

                        
                        </div>
                      
                        <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 14px;">
                        
                       </div>

                        <?php 
                            if(isset($_POST["login"]))
                            {
                                $count = 0;    
                                $username = mysqli_escape_string($conn, $_POST['username']);
                                $password = mysqli_escape_string($conn, $_POST['password']);

                                $res = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials WHERE username='$username' && password='$password'");

                                $count = mysqli_num_rows($res); 
                          
                                if($count == 0) { 
                                    
                                echo '<div class="alert alert-danger alertClass">
                                    
                                <center>
                              <!--  <button type="button" class="close" data-dismiss="alert">&times;</button> -->
                                
                                <strong>Invalid</strong> Username Or Password.
                                </center>
                                    </div> ';

                                }
                                
                                else { 
                                    $_SESSION["username"] = $username;
                                    
                                echo '<script>
                                        window.location="index.php";
                                    </script> ';
                                
                                }
                            }
                        ?>






                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 hide-lg d-none-pic grad">
        <div style="background-image: linear-gradient(
    rgba(0, 0, 0, 0.5),
    rgba(0, 0, 0, 0.5)
  ), url('../img/bg_login2.jpg'); background-size: cover; height: 100vh !important; 
        zoom: 100%; 
        overflow-y: none;">
      <!--   <img src="../img/bg_login2.jpg"  style="height: 100vh !important; 
        zoom: 100%; 
        overflow-y: none;"/> -->
    </div>
</div>
</body>
</html>

<script>
/* Optional but not required 
$("#alert-success").fadeTo(2000, 500).slideUp(500, function(){
    $("#alert-success").slideUp(500);
});
$("#alert-danger").fadeTo(5000, 500).slideUp(500, function(){
    $("#alert-danger").slideUp(500);
});
*/
</script>