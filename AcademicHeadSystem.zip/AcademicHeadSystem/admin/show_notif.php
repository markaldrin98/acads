
<style>
#alert_popover{
	position:fixed; 
    bottom: 0px; 
    left: 0px; 
    width: 100%;
    z-index:9999; 
    border-radius:0px
}

#inner-message {
    margin: 0 auto;
}</style>

<?php 
session_start();
include('connection.php');
include('tags.php');

$username = $_SESSION['username'];

$announce_query = mysqli_query($conn, "SELECT * FROM tbl_announcement_notif 
WHERE status='Pending' ORDER BY id DESC;");



$total_notif = mysqli_num_rows($announce_query); 

echo '<b><li class="dropdown-header">TOTAL NOTIFICATIONS: '.$total_notif.' </li></b>';
echo '<li class="divider"></li>';

echo '<li class="dropdown-header">Announcement for Today</li>';

if(mysqli_num_rows($announce_query) > 0){
    while($row = mysqli_fetch_array($announce_query)){ 

        echo '
        <div style="font-size: 13px; background: #f9f9f9; padding: 5px; margin: 5px; width: 300px; ">
        <a href="#.php">
        <b>'.$row['name'].'</b>'.$row['title'].'</b></a>
            <br/>
        </div>
        ';
        }
}
else{
    echo 'No records yet.';

}

echo '<li class="divider"></li>';


?>
