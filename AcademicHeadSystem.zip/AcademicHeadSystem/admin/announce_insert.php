<?php

include('connection.php');
//echo $_POST['title'];
if (isset($_POST['insert'])){
	$start = $_POST['start'];
	$end = $_POST['end'];
	$username = $_POST['username'];
	$title = $_POST['title'];
	$color = $_POST['color'];
	$announce_what = $_POST['announce_what'];
	$announce_where = $_POST['announce_where'];
	$announce_when = $_POST['announce_when'];
	$announce_description = $_POST['announce_description'];
	$announce_date = $_POST['announce_date'];
	$announce_time = $_POST['announce_time'];
	
	$sql_date_between = mysqli_query($conn, "SELECT * FROM tbl_announcement WHERE start BETWEEN '$start' AND '$end' AND title='$title' AND color='#0071c5'");
		
	$sql_insert = mysqli_query($conn, "INSERT INTO tbl_announcement(start, end, username, title, color, announce_what, announce_where, announce_when, announce_description, announce_date, announce_time) 
	values ('$start', '$end', '$username', '$title', '$color', '$announce_what', '$announce_where', '$announce_when', '$announce_description', '$announce_date', '$announce_time')");
	//$req = $bdd->prepare($sql);
	//$req->execute();
//values ('$title', '$start', '$end', '$color', '$name', '$username', '$contact_number', '$email', 'Reserved')");
		
	// echo $sql;
	
//	$res = mysqli_query($conn, $sql);

}
 header('Location: announcements_notif.php');
	
// echo '<script>console.log($sql_insert);</script>'

?>
