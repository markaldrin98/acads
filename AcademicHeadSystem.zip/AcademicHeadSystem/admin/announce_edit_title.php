<?php
include('connection.php');

if (isset($_POST['delete']) && isset($_POST['id'])){	
	$id = $_POST['id'];
	$deleteQuery = mysqli_query($conn, "DELETE FROM tbl_announcement WHERE id = $id");
//	$res = mysqli_query($conn, $deleteQuery);	
}

elseif (isset($_POST['title']) && isset($_POST['color']) && isset($_POST['id'])){
	$id = $_POST['id'];
	$title = $_POST['title'];
	$announce_what = $_POST['announce_what'];
	$announce_where = $_POST['announce_where'];
	$announce_when = $_POST['announce_when'];
	$description = $_POST['description'];
	$username = $_POST['username'];
	$color = $_POST['color'];	

		$updateQuery = mysqli_query($conn, "UPDATE tbl_announcement SET title = '$title', announce_what='$announce_what',
		announce_where='$announce_where', announce_when='$announce_when', description='$description', username='$username', color = '$color' WHERE id = $id");
	
	//$res = mysqli_query($updateQuery, $sql);
}
header('Location: announcements_notif.php');	
?>
